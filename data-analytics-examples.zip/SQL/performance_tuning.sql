-- Performance Optimization
EXPLAIN ANALYZE SELECT * FROM table_name WHERE column = 'value';