-- Basic SQL Queries
SELECT * FROM table_name LIMIT 10;