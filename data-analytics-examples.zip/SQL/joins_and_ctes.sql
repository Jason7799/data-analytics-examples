-- Joins and Common Table Expressions (CTEs)
WITH cte AS (SELECT * FROM table_name) SELECT * FROM cte;